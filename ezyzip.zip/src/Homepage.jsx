import React from 'react'
import "./Homepage.css"
import Timeline from './timeline/Timeline'

function Homepage() {
  return (
  <>
    <Timeline />

    </>
  )    

}

export default Homepage